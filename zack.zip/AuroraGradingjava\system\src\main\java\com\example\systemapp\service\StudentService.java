package com.example.systemapp.service;

import com.example.systemapp.model.GradeRecord;
import com.example.systemapp.model.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class StudentService {

    private final ObservableList<Student> students = FXCollections.observableArrayList();

    public ObservableList<Student> getStudents() {
        return students;
    }

    public void addGrade(String name, String email, String subject, double score) {
        Student student = students.stream()
                .filter(s -> s.getEmail().equalsIgnoreCase(email))
                .findFirst()
                .orElseGet(() -> {
                    Student created = new Student(name, email);
                    students.add(created);
                    return created;
                });
        student.addGrade(new GradeRecord(subject, score));
    }
}

