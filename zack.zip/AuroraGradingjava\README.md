# Aurora Grading JavaFX

Modern JavaFX desktop application for managing student grades.

## Repository structure

```
AuroraGradingjava/
  README.md
  system/
    src/...
    buildSystem.ps1
    runSystem.ps1
    getJavaFx.ps1   # downloads JavaFX runtime on demand
```

## Quick start

```powershell
cd system
.\getJavaFx.ps1      # downloads JavaFX SDK (not tracked in git)
.\buildSystem.ps1    # compiles sources to out/
.\runSystem.ps1      # launches the GUI
```

This keeps the repo lightweight (no bundled SDK binaries) while still allowing a single command to fetch the dependencies when needed.

