package com.example.systemapp.model;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Student {
    private final StringProperty name = new SimpleStringProperty();
    private final StringProperty email = new SimpleStringProperty();
    private final ObservableList<GradeRecord> grades = FXCollections.observableArrayList();

    public Student(String name, String email) {
        this.name.set(name);
        this.email.set(email);
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getEmail() {
        return email.get();
    }

    public StringProperty emailProperty() {
        return email;
    }

    public ObservableList<GradeRecord> getGrades() {
        return grades;
    }

    public void addGrade(GradeRecord gradeRecord) {
        grades.add(gradeRecord);
    }

    public double getAverage() {
        return grades.stream().mapToDouble(GradeRecord::getScore).average().orElse(0);
    }

    public double getGpa() {
        return grades.stream().mapToDouble(record -> toPoints(record.getScore())).average().orElse(0);
    }

    public String getLetterGrade() {
        double average = getAverage();
        if (average >= 90) return "A";
        if (average >= 80) return "B";
        if (average >= 70) return "C";
        if (average >= 60) return "D";
        return "F";
    }

    private double toPoints(double score) {
        if (score >= 90) return 4.0;
        if (score >= 80) return 3.0;
        if (score >= 70) return 2.0;
        if (score >= 60) return 1.0;
        return 0.0;
    }
}

