package com.example.systemapp.service;

import com.example.systemapp.model.AppTheme;
import javafx.scene.Scene;

public final class ThemeManager {
    private static final String STYLESHEET = ThemeManager.class.getResource("/css/styles.css").toExternalForm();

    private ThemeManager() {
    }

    public static void apply(Scene scene, AppTheme theme) {
        if (!scene.getStylesheets().contains(STYLESHEET)) {
            scene.getStylesheets().add(STYLESHEET);
        }
        scene.getRoot().getStyleClass().removeAll("theme-light", "theme-dark");
        scene.getRoot().getStyleClass().add(theme == AppTheme.DARK ? "theme-dark" : "theme-light");
    }
}

