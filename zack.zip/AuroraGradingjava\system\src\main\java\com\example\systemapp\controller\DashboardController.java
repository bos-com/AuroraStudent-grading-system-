package com.example.systemapp.controller;

import com.example.systemapp.MainApp;
import com.example.systemapp.model.Student;
import com.example.systemapp.service.SettingsService;
import com.example.systemapp.service.StudentService;
import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;

public class DashboardController {

    @FXML
    private TableView<Student> studentTable;
    @FXML
    private TableColumn<Student, String> nameColumn;
    @FXML
    private TableColumn<Student, String> emailColumn;
    @FXML
    private TableColumn<Student, Number> averageColumn;
    @FXML
    private TableColumn<Student, Number> gpaColumn;
    @FXML
    private TableColumn<Student, String> letterColumn;
    @FXML
    private ListView<String> gradeList;
    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField subjectField;
    @FXML
    private TextField scoreField;
    @FXML
    private Label welcomeLabel;

    private MainApp mainApp;
    private StudentService studentService;
    private SettingsService settingsService;

    public void initialize(MainApp mainApp, StudentService studentService, SettingsService settingsService) {
        this.mainApp = mainApp;
        this.studentService = studentService;
        this.settingsService = settingsService;
        configureTable();
        ObservableList<Student> students = studentService.getStudents();
        studentTable.setItems(students);
        welcomeLabel.setText("Welcome back, " + settingsService.getUsername());
    }

    private void configureTable() {
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());
        emailColumn.setCellValueFactory(data -> data.getValue().emailProperty());
        averageColumn.setCellValueFactory(data -> Bindings.createDoubleBinding(data.getValue()::getAverage));
        gpaColumn.setCellValueFactory(data -> Bindings.createDoubleBinding(data.getValue()::getGpa));
        letterColumn.setCellValueFactory(data -> Bindings.createStringBinding(data.getValue()::getLetterGrade));

        studentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            gradeList.getItems().clear();
            if (newVal != null) {
                newVal.getGrades().forEach(grade ->
                        gradeList.getItems().add(grade.getSubject() + ": " + String.format("%.1f", grade.getScore())));
            }
        });
    }

    @FXML
    private void handleAddGrade() {
        try {
            String name = nameField.getText();
            String email = emailField.getText();
            String subject = subjectField.getText();
            double score = Double.parseDouble(scoreField.getText());
            studentService.addGrade(name, email, subject, score);
            nameField.clear();
            subjectField.clear();
            scoreField.clear();
        } catch (NumberFormatException ex) {
            showError("Score must be a valid number between 0 and 100.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    @FXML
    private void handleSettings() {
        try {
            mainApp.openSettingsDialog();
        } catch (IOException e) {
            showError("Unable to open settings.");
        }
    }

    @FXML
    private void handleLogout() {
        try {
            mainApp.logout();
        } catch (IOException e) {
            showError("Unable to logout.");
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(message);
        alert.showAndWait();
    }
}

