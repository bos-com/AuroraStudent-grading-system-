param(
    [string]$Version = "23.0.1",
    [string]$Platform = "windows-x64"
)

$targetDir = "javafx-sdk-$Version"
if (Test-Path $targetDir) {
    Write-Host "JavaFX runtime already present at '$targetDir'."
    exit 0
}

$url = "https://download2.gluonhq.com/openjfx/$Version/openjfx-$Version`_$Platform`_bin-sdk.zip"
$zipPath = "javafx-sdk.zip"

Write-Host "Downloading JavaFX $Version for $Platform ..."
Invoke-WebRequest -Uri $url -OutFile $zipPath

Write-Host "Extracting ..."
Expand-Archive -Path $zipPath -DestinationPath . -Force

Remove-Item $zipPath -Force
Write-Host "JavaFX extracted to '$targetDir'."


