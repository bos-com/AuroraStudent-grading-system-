$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Aurora Grading System.lnk"
$target = "powershell.exe"
$arguments = "-ExecutionPolicy Bypass -File `"$projectRoot\\runSystem.ps1`""

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $target
$shortcut.Arguments = $arguments
$shortcut.WorkingDirectory = $projectRoot
$shortcut.WindowStyle = 1
$shortcut.IconLocation = "$projectRoot\\javafx-sdk-23.0.1\\lib\\javafx-swt.jar,0"
$shortcut.Save()

Write-Host "Shortcut created at $shortcutPath"

