package com.example.systemapp.service;

public class AuthService {
    private final SettingsService settingsService;

    public AuthService(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    public boolean authenticate(String username, String password) {
        return settingsService.matches(username, password);
    }
}

