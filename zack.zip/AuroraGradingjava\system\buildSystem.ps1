param(
    [string]$OutDir = "out",
    [string]$JavaFxLib = "javafx-sdk-23.0.1\\lib"
)

if (-not (Test-Path $JavaFxLib)) {
    Write-Error "JavaFX library path '$JavaFxLib' not found."
    exit 1
}

if (-not (Test-Path $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir | Out-Null
}

$sources = Get-ChildItem -Path "src\\main\\java" -Filter *.java -Recurse | ForEach-Object { $_.FullName }

if (-not $sources) {
    Write-Error "No Java sources detected."
    exit 1
}

javac --module-path $JavaFxLib --add-modules javafx.controls,javafx.fxml `
    -d $OutDir $sources

Copy-Item -Path "src\\main\\resources\\*" -Destination $OutDir -Recurse -Force

Write-Host "Build successful. Classes + resources copied to '$OutDir'."

