package com.example.systemapp;

import com.example.systemapp.controller.DashboardController;
import com.example.systemapp.controller.LoginController;
import com.example.systemapp.controller.SettingsController;
import com.example.systemapp.model.AppTheme;
import com.example.systemapp.service.AuthService;
import com.example.systemapp.service.SettingsService;
import com.example.systemapp.service.StudentService;
import com.example.systemapp.service.ThemeManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {

    private Stage primaryStage;
    private Scene mainScene;
    private SettingsService settingsService;
    private AuthService authService;
    private StudentService studentService;

    @Override
    public void start(Stage stage) throws Exception {
        this.primaryStage = stage;
        this.settingsService = new SettingsService();
        this.authService = new AuthService(settingsService);
        this.studentService = new StudentService();
        stage.setTitle("Aurora Grading Suite");
        showLogin();
        stage.show();
    }

    public void showLogin() throws IOException {
        FXMLLoader loader = new FXMLLoader(MainApp.class.getResource("/fxml/login-view.fxml"));
        Parent root = loader.load();
        LoginController controller = loader.getController();
        controller.initialize(this, authService);
        applyScene(root);
    }

    public void showDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(MainApp.class.getResource("/fxml/dashboard-view.fxml"));
        Parent root = loader.load();
        DashboardController controller = loader.getController();
        controller.initialize(this, studentService, settingsService);
        applyScene(root);
    }

    public void openSettingsDialog() throws IOException {
        FXMLLoader loader = new FXMLLoader(MainApp.class.getResource("/fxml/settings-view.fxml"));
        Parent root = loader.load();
        SettingsController controller = loader.getController();
        controller.initialize(this, settingsService, authService);

        Stage dialog = new Stage();
        dialog.initOwner(primaryStage);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Settings");
        Scene scene = new Scene(root);
        ThemeManager.apply(scene, settingsService.getTheme());
        dialog.setScene(scene);
        dialog.showAndWait();
        ThemeManager.apply(mainScene, settingsService.getTheme());
    }

    private void applyScene(Parent root) {
        if (mainScene == null) {
            mainScene = new Scene(root, 1100, 700);
            primaryStage.setScene(mainScene);
        } else {
            mainScene.setRoot(root);
        }
        ThemeManager.apply(mainScene, settingsService.getTheme());
    }

    public void logout() throws IOException {
        showLogin();
    }

    public void refreshTheme() {
        if (mainScene != null) {
            ThemeManager.apply(mainScene, settingsService.getTheme());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

