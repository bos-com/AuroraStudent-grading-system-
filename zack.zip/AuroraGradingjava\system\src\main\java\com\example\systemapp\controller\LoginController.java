package com.example.systemapp.controller;

import com.example.systemapp.MainApp;
import com.example.systemapp.service.AuthService;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private MainApp mainApp;
    private AuthService authService;

    public void initialize(MainApp mainApp, AuthService authService) {
        this.mainApp = mainApp;
        this.authService = authService;
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        if (authService.authenticate(username, password)) {
            try {
                mainApp.showDashboard();
            } catch (IOException e) {
                showError("Unable to load dashboard", e.getMessage());
            }
        } else {
            showError("Invalid credentials", "Please try again.");
        }
    }

    @FXML
    private void handleExit() {
        Platform.exit();
    }

    private void showError(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Login failed");
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

