## Aurora Grading Suite (JavaFX)

Modern desktop UI for managing student grades with login, dashboard analytics, and customizable theme.

### Prerequisites
- Java 17+
- Windows PowerShell (included)

### Project layout
```
system/
  src/main/java/...      # Application sources
  src/main/resources/... # FXML + CSS
  getJavaFx.ps1          # Downloads JavaFX runtime (not committed)
  buildSystem.ps1        # Compile helper
  runSystem.ps1          # Launch helper
  createShortcut.ps1     # Generates Desktop shortcut
```

### Download JavaFX runtime (one-time or when upgrading)
```
.\getJavaFx.ps1
```
This fetches the latest JavaFX SDK referenced by the scripts into `javafx-sdk-23.0.1/`. You can delete that folder at any time and rerun the script to keep the repo slim.

### Build
From `system/`:
```
.\buildSystem.ps1
```
This compiles the JavaFX sources into `out/` and copies resources.

### Run
```
.\runSystem.ps1
```
Default credentials: `admin / admin123`.

### Desktop shortcut
After the first build/run, execute:
```
.\createShortcut.ps1
```
An “Aurora Grading System” shortcut appears on your desktop and launches the GUI via `runSystem.ps1`.

### Features
- Animated login with credential validation (username + password stored securely via `java.util.prefs`).
- Dashboard showing students, GPA/average columns, and quick grade entry form.
- Settings modal to switch between light/dark themes and update credentials.
- Responsive layouts styled with modern glassmorphism-inspired CSS.

### Next steps
- Persist students using a database (e.g., MongoDB Atlas or SQLite).
- Add charts (JavaFX `PieChart`, `AreaChart`) for performance visualization.
- Bundle into a native installer using jpackage.

