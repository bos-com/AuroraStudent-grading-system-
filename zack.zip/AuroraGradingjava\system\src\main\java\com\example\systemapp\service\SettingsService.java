package com.example.systemapp.service;

import com.example.systemapp.model.AppTheme;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.prefs.Preferences;

public class SettingsService {
    private static final String NODE = "com.example.systemapp";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_THEME = "theme";

    private final Preferences preferences = Preferences.userRoot().node(NODE);

    public SettingsService() {
        if (preferences.get(KEY_USERNAME, null) == null) {
            preferences.put(KEY_USERNAME, "admin");
            preferences.put(KEY_PASSWORD, hash("admin123"));
            preferences.put(KEY_THEME, AppTheme.LIGHT.name());
        }
    }

    public String getUsername() {
        return preferences.get(KEY_USERNAME, "admin");
    }

    public void updateCredentials(String username, String password) {
        preferences.put(KEY_USERNAME, username);
        if (password != null && !password.isBlank()) {
            preferences.put(KEY_PASSWORD, hash(password));
        }
    }

    public boolean matches(String username, String password) {
        String storedHash = preferences.get(KEY_PASSWORD, "");
        return getUsername().equalsIgnoreCase(username) && storedHash.equals(hash(password));
    }

    public AppTheme getTheme() {
        return AppTheme.valueOf(preferences.get(KEY_THEME, AppTheme.LIGHT.name()));
    }

    public void setTheme(AppTheme theme) {
        preferences.put(KEY_THEME, theme.name());
    }

    private String hash(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hashed);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Unable to hash credentials", e);
        }
    }
}

