$JavaFxLib = "javafx-sdk-23.0.1\lib"

if (-not (Test-Path $JavaFxLib)) {
    Write-Error "JavaFX libraries missing. Run buildSystem.ps1 first."
    exit 1
}

$classPath = "out"

java --module-path $JavaFxLib `
     --add-modules javafx.controls,javafx.fxml `
     -cp $classPath com.example.systemapp.MainApp

