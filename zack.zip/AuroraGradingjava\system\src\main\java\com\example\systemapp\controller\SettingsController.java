package com.example.systemapp.controller;

import com.example.systemapp.MainApp;
import com.example.systemapp.model.AppTheme;
import com.example.systemapp.service.AuthService;
import com.example.systemapp.service.SettingsService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class SettingsController {

    @FXML
    private ComboBox<AppTheme> themeCombo;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confirmField;
    @FXML
    private Label statusLabel;

    private MainApp mainApp;
    private SettingsService settingsService;
    private AuthService authService;

    public void initialize(MainApp mainApp, SettingsService settingsService, AuthService authService) {
        this.mainApp = mainApp;
        this.settingsService = settingsService;
        this.authService = authService;
        themeCombo.setItems(FXCollections.observableArrayList(AppTheme.values()));
        themeCombo.setValue(settingsService.getTheme());
        usernameField.setText(settingsService.getUsername());
    }

    @FXML
    private void handleSave() {
        AppTheme selectedTheme = themeCombo.getValue();
        settingsService.setTheme(selectedTheme);

        if (!passwordField.getText().isBlank() || !confirmField.getText().isBlank()) {
            if (!passwordField.getText().equals(confirmField.getText())) {
                statusLabel.setText("Passwords do not match.");
                return;
            }
            settingsService.updateCredentials(usernameField.getText(), passwordField.getText());
        } else {
            settingsService.updateCredentials(usernameField.getText(), null);
        }

        statusLabel.setText("Settings saved successfully.");
        mainApp.refreshTheme();
    }

    @FXML
    private void handleClose() {
        statusLabel.getScene().getWindow().hide();
    }
}

