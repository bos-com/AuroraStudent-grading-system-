package com.example.systemapp.model;

public enum AppTheme {
    LIGHT,
    DARK
}

