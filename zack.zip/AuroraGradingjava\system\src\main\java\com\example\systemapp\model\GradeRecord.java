package com.example.systemapp.model;

import java.util.Objects;

public class GradeRecord {
    private final String subject;
    private final double score;

    public GradeRecord(String subject, double score) {
        if (subject == null || subject.isBlank()) {
            throw new IllegalArgumentException("Subject must not be empty");
        }
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100");
        }
        this.subject = subject.trim();
        this.score = score;
    }

    public String getSubject() {
        return subject;
    }

    public double getScore() {
        return score;
    }

    @Override
    public String toString() {
        return subject + " - " + score;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GradeRecord that)) return false;
        return Double.compare(that.score, score) == 0 && subject.equals(that.subject);
    }

    @Override
    public int hashCode() {
        return Objects.hash(subject, score);
    }
}

